==============================================
    SE/OOP/2023/S2/MLB/WD/G159 - StockWorX
==============================================
	Online Stock Management System
----------------------------------------------


----------------------------------------------
          *** LOGIN CREDENTIALS ***
----------------------------------------------
Included in - Login Credentials.pdf

* Log in according to the role
----------------------------------------------


----------------------------------------------
         *** DATABASE CREDENTIALS ***
----------------------------------------------
SQL file: stockworx.sql
Server url: "jdbc:mysql://localhost:3306/stockworx"
Database connection path: /src/main/java/com/user/DBConnect.java
Schema name: stockworx
----------------------------------------------


----------------------------------------------
           *** ROLES & FUNCTIONS ***
----------------------------------------------
1) Buyer - Product Catalog, My Orders, Feedback
2) Sales Manager - Stock Requests, Stock Orders
3) Manager - Manage Products, Buyer Orders, Stock Orders, Stock Availability
4) Admin - Admin Panel, Add New User
5) Warehouse Staff - Approved Buyer Orders, Request Stock, Delivery Queue
6) Manufacturer - Ready Up Stock Orders
----------------------------------------------

